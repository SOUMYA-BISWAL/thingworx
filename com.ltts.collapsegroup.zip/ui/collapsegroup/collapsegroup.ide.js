TW.IDE.Widgets.collapsegroup = function () {

	var thisWidget = this;
	var roundedCorners = false;
	this.widgetIconUrl = function() {
		return  "'../Common/extensions/com.ltts.com.collapsegroup/ui/collapsegroup/default_widget_icon.ide.png'";
	};

	
	//below code for set properties
	this.widgetProperties = function () {
		return {
			'name': 'collapsegroup',
            'description': 'collapsegroup',
			'category': ['Common'],
            'supportsLabel': true,
			'iconImage': 'default_widget_icon.ide.png',
            'supportsTooltip': true,
            'isVisible': true,
			'properties': {
				'CustomClass': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.custom-class.description'),
                    'baseType': 'STRING',
                    'isLocalizable': false,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isVisible': true
                 },
				'CollapseText': {
				'baseType': 'STRING',
				'defaultValue': 'This is collapse text',
				'isBindingTarget': true
				},
				'CollapseHeader': {
					'baseType': 'STRING',
					'defaultValue': 'Open Collapse',
					'isBindingTarget': true
				},
				'Width': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.width.description'),
                    'baseType': 'NUMBER',
                },
                'Height': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.height.description'),
                    'baseType': 'NUMBER',
                    'isEditable': true
                },
                'TabSequence': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.tabSequence.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'RoundedCorner': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.roundedCorners.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'HeaderStyle': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.style.description'),
                    'baseType': 'STYLEDEFINITION'/*,
                    'defaultValue': 'DefaultButtonStyle'*/
                },
                'BodyStyle': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.hover-style.description'),
                    'baseType': 'STYLEDEFINITION'/*,
                    'defaultValue': 'DefaultButtonHoverStyle'*/
                },
                'TabSequence': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.tabSequence.description'),
                    'baseType': 'NUMBER',
                    'isVisible': false,
                    'defaultValue': 0
                },
                'IconAlignment': {
                    'description': TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.icon-alignment.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'left',
                    'isVisible': false,
                    'selectOptions': [
                        { value: 'left', text: TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.icon-alignment.select-options.left') },
                        { value: 'right', text: TW.IDE.I18NController.translate('tw.collapsegroup-ide.properties.icon-alignment.select-options.right') }
                    ]
                }
			}
		}
	};

	//below code for event click
/*	this.widgetEvents = function () {
        return {
            'Clicked': { 'warnIfNotBound': true, 'description': TW.IDE.I18NController.translate('tw.thingworx-ide-widget.default-events.clicked.description') }
        };
    };*/
	
    
    
	this.afterSetProperty = function (name, value) {
		
		var refreshHtml = false;
		switch (name) {
	        case 'HeaderStyle':
	        case 'BodyStyle':
	        case 'FocusStyle':
	        case 'Width':
	        case 'Height':
	        case 'RoundedCorner':
			case 'CollapseText':
				thisWidget.jqElement.find('.anotherContent').text(value);
			case 'CollapseHeader':
				thisWidget.jqElement.find('.collapsible').text(value);
			case 'IconAlignment':
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};
	
	this.renderHtml = function () {

		// Style Property
			var formatResultForHeader = TW.getStyleFromStyleDefinition(this.getProperty('HeaderStyle'));
			var formatResultForBody = TW.getStyleFromStyleDefinition(this.getProperty('BodyStyle'));
			
		//style property for header
	        var textSizeClassForHeader = 'textsize-normal';
	        if (this.getProperty('HeaderStyle') !== undefined) {
	        	textSizeClassForHeader = TW.getTextSizeClassName(formatResultForHeader.textSize);
	        }
	        var cssInfoForHeader = TW.getStyleCssTextualFromStyle(formatResultForHeader);
			var cssTextBoxTextForHeader = TW.getStyleCssTextualNoBackgroundFromStyle(formatResultForHeader);
			var TextboxStyleBorderForHeader = TW.getStyleCssBorderFromStyle(formatResultForHeader);
			
		//style property for body
	        var textSizeClassForBody = 'textsize-normal';
	        if (this.getProperty('HeaderStyle') !== undefined) {
	            textSizeClassForBody = TW.getTextSizeClassName(formatResultForBody.textSize);
	        }
	        var cssInfoForBody = TW.getStyleCssTextualFromStyle(formatResultForBody);
			var cssTextBoxTextForBody = TW.getStyleCssTextualNoBackgroundFromStyle(formatResultForBody);
			var TextboxStyleBorderForBody = TW.getStyleCssBorderFromStyle(formatResultForBody);
	        
			
			//HTML code for collapsegroup widget
			
			return 	'<div class="widget-content widget-collapsegroup">'
						+'<button type="button" class="collapsible ' +textSizeClassForHeader+ '" style="'+cssInfoForHeader+'">' + this.getProperty('CollapseHeader') +'</button>' 
						+'<div class="content" style="'+cssInfoForBody+'">' 
							+'<p class=" anotherContent '+textSizeClassForBody+'">' + this.getProperty('CollapseText') + '</p>' 
						+'</div>'  
					+'</div>';
		};

		
		this.afterRender = function () {
			
			var button = this.jqElement.find('.collapsible');
			TW.log.debug(button);
			button.text(this.getProperty('CollapseHeader'));
			
			var content = this.jqElement.find('.anotherContent');
			TW.log.debug(content.text());
			content.text(this.getProperty('CollapseText'));
			
			roundedCorners = this.getProperty('RoundedCorner');
	        if (roundedCorners === undefined) {
	            roundedCorners = false;
	        }
	        if (roundedCorners === true) {
	        	button.css('border-radius', '6px');
	        }
	        
	        //change height for collapse button
	        var buttonHeight = this.getProperty('Height');
	        var resource = TW.IDE.getMashupResource();
	        var buttonHeightValue = buttonHeight + 'px';
	        if (this.hasCustomClass) {
	        	buttonHeightValue = '100%';
	        }
	        var widgetStyles = '#' + thisWidget.jqElementId + ' .collapsible { height: ' + buttonHeightValue + '; }';
	        resource.styles.append(widgetStyles);
	        
		};
		
		this.updateProperty = function (updatePropertyInfo) {
			// TargetProperty tells you which of your bound properties changed
			if (updatePropertyInfo.TargetProperty === 'CollapseHeader') {
				button.text(updatePropertyInfo.SinglePropertyValue);
				this.setProperty('CollapseHeader', updatePropertyInfo.SinglePropertyValue);
			}
			if (updatePropertyInfo.TargetProperty === 'CollapseText') {
				content.text(updatePropertyInfo.SinglePropertyValue);
				this.setProperty('CollapseText', updatePropertyInfo.SinglePropertyValue);
			}
		};

};