TW.Runtime.Widgets.collapsegroup= function () {
	var valueElem, button, content;
	var thisWidget = this;
	var roundedCorners = false;
	
	// runtime properties
	this.runtimeProperties = function () {
        return {
            'supportsTooltip': true,
            'propertyAttributes': {
                 'ToolTipField': {
                     'isLocalizable': true
                 	}
            	}
        	}
        };
	
	//below function used for render HTML in view mashup(runtime)
	this.renderHtml = function() {
		// Style Property
		var formatResultForHeader = TW.getStyleFromStyleDefinition(this.getProperty('HeaderStyle'));
		var formatResultForBody = TW.getStyleFromStyleDefinition(this.getProperty('BodyStyle'));
		
	//style property for header
        var textSizeClassForHeader = 'textsize-normal';
        if (this.getProperty('HeaderStyle') !== undefined) {
        	textSizeClassForHeader = TW.getTextSizeClassName(formatResultForHeader.textSize);
        }
        var cssInfoForHeader = TW.getStyleCssTextualFromStyle(formatResultForHeader);
		var cssTextBoxTextForHeader = TW.getStyleCssTextualNoBackgroundFromStyle(formatResultForHeader);
		var TextboxStyleBorderForHeader = TW.getStyleCssBorderFromStyle(formatResultForHeader);
		
	//style property for body
        var textSizeClassForBody = 'textsize-normal';
        if (this.getProperty('HeaderStyle') !== undefined) {
            textSizeClassForBody = TW.getTextSizeClassName(formatResultForBody.textSize);
        }
        var cssInfoForBody = TW.getStyleCssTextualFromStyle(formatResultForBody);
		var cssTextBoxTextForBody = TW.getStyleCssTextualNoBackgroundFromStyle(formatResultForBody);
		var TextboxStyleBorderForBody = TW.getStyleCssBorderFromStyle(formatResultForBody);
        
	//html code for	render HTML in view mashup(runtime)
		return 	'<div class="widget-content widget-collapsegroup">' +
					'<button type="button" class="collapsible ' +textSizeClassForHeader+ '" style="'+cssInfoForHeader+'">' + this.getProperty('CollapseHeader') +'</button>' 
					+'<div class="content" style="'+cssInfoForBody+'">' +
						'<p class=" anotherContent '+textSizeClassForBody+'">' + this.getProperty('CollapseText') + '</p>' +
					'</div>' + 
				'</div>';
	};


	//all collapse button functionality logic inside this method
	this.afterRender = function () {
		TW.log.debug("Updated Code");
		
		button = this.jqElement.find('.collapsible');
		button.text(this.getProperty('CollapseHeader'));
		
		var buttonHeight = this.getProperty('Height');
		TW.log.debug("buttonHeight : "+buttonHeight);
		var buttonHeightValue = buttonHeight + 'px';
		button.css('height', buttonHeightValue);
		
		roundedCorners = this.getProperty('RoundedCorner');
        if (roundedCorners === undefined) {
            roundedCorners = false;
        }
        if (roundedCorners === true) {
        	button.css('border-radius', '6px');
        }
		
		content = this.jqElement.find('.anotherContent');
		content.text(this.getProperty('CollapseText'));
		content.css('display', 'none');
		button.click(function(e){
			TW.log.debug("Button Clicked");
			var displayValue = content.css("display");
			TW.log.debug("displayValue -> " + displayValue);
			if (displayValue === "block") {
				TW.log.debug("true");
				content.css('display', 'none');
			} else {
				TW.log.debug("false");
				content.css('display', 'block');
			}
		});
		

		
		
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		
		//set ToolTipField value at runtime
		if (updatePropertyInfo.TargetProperty === 'ToolTipField') {
            thisWidget.setProperty('ToolTipField', updatePropertyInfo.SinglePropertyValue);
        }
		
		// TargetProperty tells you which of your bound properties changed
		// Binding  CollapseHeader value from other properties
		if (updatePropertyInfo.TargetProperty === 'CollapseHeader') {
			button.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('CollapseHeader', updatePropertyInfo.SinglePropertyValue);
		}
		
		// Binding  CollapseText value from other properties
		if (updatePropertyInfo.TargetProperty === 'CollapseText') {
			content.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('CollapseText', updatePropertyInfo.SinglePropertyValue);
		}
	};
};