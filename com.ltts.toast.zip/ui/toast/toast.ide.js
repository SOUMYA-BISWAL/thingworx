TW.IDE.Widgets.toast = function () {
	var roundedCorners = true;
	this.widgetIconUrl = function() {
		return  "'../Common/extensions/com.ltts.toast/ui/toast/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'toast',
			'description': '',
			'category': ['Common'],
			'supportsAutoResize': true,
			'isResizable':true,
            'supportsLabel': true,
            'supportsResetInputToDefault': true,
			'properties': {
				'CustomClass': {
                    'description': TW.IDE.I18NController.translate('tw.toast-ide.properties.custom-class.description'),
                    'baseType': 'STRING',
                    'isLocalizable': false,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isVisible': false
                 },
                 'Width': {
                     'description': TW.IDE.I18NController.translate('tw.textbox-ide.properties.width.description')
                 },
                 'Height': {
                     'description': TW.IDE.I18NController.translate('tw.textbox-ide.properties.height.description'),
                     'isEditable': false
                 },
				'ToastsHeader': {
					'baseType': 'STRING',
					'defaultValue': 'toasts Property default value',
					'isBindingTarget': true
				},
				'ToastsBody': {
					'baseType': 'STRING',
					'defaultValue': 'toasts body default value',
					'isBindingTarget': true
				},
				'TabSequence': {
                    'description': TW.IDE.I18NController.translate('tw.toast-ide.properties.tabSequence.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'RoundedCorners': {
                    'description': TW.IDE.I18NController.translate('tw.toast-ide.properties.roundedCorners.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'Header Style': {
                    'description': TW.IDE.I18NController.translate('tw.toast-ide.properties.style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultButtonStyle'
                },
                'Body Style': {
                    'description': TW.IDE.I18NController.translate('tw.toast-ide.properties.style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultButtonStyle'
                },
                 'Visible': {
                     'isBindingTarget': true,
                     'baseType': 'BOOLEAN',
                     'defaultValue': true,
                     'description': TW.IDE.I18NController.translate('tw.toast-ide.properties.visible.description')
               }
			}
		}
	};
	

	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Header Style':
			case 'Body Style':
            case 'Width':
            case 'Height':
			case 'ToastsHeader':
			case 'ToastsBody':
			case 'RoundedCorners':
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		
		//for header style
	        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Header Style'));
	        var textSizeClass = 'textsize-normal';
			var textAlignClass = this.getProperty('ToastsHeader');
	        if (this.getProperty('Header Style') !== undefined) {
	            textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
	        }
	        var cssInfo = TW.getStyleCssTextualFromStyle(formatResult);
			var cssTextBoxText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
			var TextboxStyleBorder = TW.getStyleCssBorderFromStyle(formatResult);
			
		//for body style
			var formatResult2 = TW.getStyleFromStyleDefinition(this.getProperty('Body Style'));
	        var textSizeClass2 = 'textsize-normal';
			var textAlignClass2 = this.getProperty('ToastsBody');
	        if (this.getProperty('Body Style') !== undefined) {
	            textSizeClass2 = TW.getTextSizeClassName(formatResult2.textSize);
	        }
	        var cssInfo2 = TW.getStyleCssTextualFromStyle(formatResult2);
			var cssTextBoxText2 = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult2);
			var TextboxStyleBorder2 = TW.getStyleCssBorderFromStyle(formatResult2);
		
		
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-toast">'
				+'<div class="outerdiv" style="'+cssInfo2+'">'
					+'<div class="innerdiv" style="'+cssInfo+'" height="100%" width="100%">'
						+'<br>'
							+'<button class="crossbtn">X</button>'
							+'<h1 style="padding-left: 10px;" class ="'+textSizeClass+'">'+this.getProperty('ToastsHeader')+'</h1>'
				        +'<br>'
				    +'</div>'
				       +'<br>'
				    +'<div class="w3-container">'
				    	+'<p class ="'+textSizeClass2+'">'+this.getProperty('ToastsBody')+'</p>'
			        +'</div>'
			        +'<br>'
		        +'</div>'
				+'</div>';		
	};

	this.afterRender = function () {
		console.log("soumya design time ranjan")
		
		var buttonStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));
		
		var buttonBackground = TW.getStyleCssGradientFromStyle(buttonStyle);
        var buttonText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonStyle);
        var buttonBorder = TW.getStyleCssBorderFromStyle(buttonStyle);
		
		roundedCorners = this.getProperty('RoundedCorners');
        if (roundedCorners === undefined) {
            roundedCorners = true;
        }

        if (roundedCorners === true) {
            thisWidget.jqElement.addClass('roundedCorners');
        }
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		//var valueElem = this.jqElement.find('.header');
		//TW.log.debug(valueElem);
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		//valueElem.text(this.getProperty('toastsHeader'));
		
		//var bodyValue = '';
		//bodyValue.text(this.getProperty('toastsBody'));
		//TW.log.debug(bodyValue);
	};

};