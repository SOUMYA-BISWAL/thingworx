TW.Runtime.Widgets.toast= function () {
	var valueElem, button, content;
	var roundedCorners = true;
	this.renderHtml = function () {
		
	//for header style
        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Header Style'));
        var textSizeClass = 'textsize-normal';
		var textAlignClass = this.getProperty('ToastsHeader');
        if (this.getProperty('Header Style') !== undefined) {
            textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
        }
        var cssInfo = TW.getStyleCssTextualFromStyle(formatResult);
		var cssTextBoxText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
		var TextboxStyleBorder = TW.getStyleCssBorderFromStyle(formatResult);
		
	//for body style
		var formatResult2 = TW.getStyleFromStyleDefinition(this.getProperty('Body Style'));
        var textSizeClass2 = 'textsize-normal';
		var textAlignClass2 = this.getProperty('ToastsBody');
        if (this.getProperty('Body Style') !== undefined) {
            textSizeClass2 = TW.getTextSizeClassName(formatResult2.textSize);
        }
        var cssInfo2 = TW.getStyleCssTextualFromStyle(formatResult2);
		var cssTextBoxText2 = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult2);
		var TextboxStyleBorder2 = TW.getStyleCssBorderFromStyle(formatResult2);
		
		
		
		return 	'<div class="widget-content widget-toast">'
				+'<div class="outerdiv" style="'+cssInfo2+'">'
					+'<div class="innerdiv" style="'+cssInfo+'" height="100%" width="100%">'
						+'<br>'
							+'<button class="crossbtn">X</button>'
					        +'<h1 style="padding-left: 10px;" class ="'+textSizeClass+'">'+this.getProperty('ToastsHeader')+'</h1>'
				        +'<br>'
				    +'</div>'
				       +'<br>'
				    +'<div class="w3-container">'
				        +'<p class ="'+textSizeClass2+'">'+this.getProperty('ToastsBody')+'</p>'
			        +'</div>'
			        +'<br>'
		        +'</div>'
				+'</div>';		
		};

	this.afterRender = function () {
		console.log("soumya ranjan")
		
		roundedCorners = this.getProperty('RoundedCorners');
            if (roundedCorners === undefined) {
                roundedCorners = true;
            }
		
		button = this.jqElement.find('.crossbtn');
		content = this.jqElement.find('.outerdiv');
		
		
		button.click(function(e){
			TW.log.debug("button clicked");
			content.css('display', 'none');
			TW.log.debug(hei);
			TW.log.debug(wei);
		});
		
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'ToastsHeader') {
			valueElem.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('ToastsHeader', updatePropertyInfo.SinglePropertyValue);
		}
		if (updatePropertyInfo.TargetProperty === 'ToastsBody') {
			valueElem.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('ToastsBody', updatePropertyInfo.SinglePropertyValue);
		}
	};
};