TW.IDE.Widgets.hello = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/hello/ui/hello/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'hello',
			'description': 'hello',
			'category': ['Common'],
			'properties': {
				'CollapseText': {
					'baseType': 'STRING',
					'defaultValue': 'This is collapse text',
					'isBindingTarget': true
				},
				'ButtonText': {
					'baseType': 'STRING',
					'defaultValue': 'Opne Collapse',
					'isBindingTarget': true
				},
				'Style': {
                    'isBindingTarget': (TW.IDE.checkCustomCSS === true) ? true : false,
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLabelStyle',
                    'description': TW.IDE.I18NController.translate('tw.label-ide.properties.style.description')
                },
                'Alignment': {
                    'baseType': 'STRING',
                    'defaultValue': 'left',
                    'selectOptions': [
                        { value: 'left', text: TW.IDE.I18NController.translate('tw.label-ide.properties.alignment.select-options.left') },
                        { value: 'right', text: TW.IDE.I18NController.translate('tw.label-ide.properties.alignment.select-options.right') },
                        { value: 'center', text: TW.IDE.I18NController.translate('tw.label-ide.properties.alignment.select-options.center') }
                    ],
                    'description': TW.IDE.I18NController.translate('tw.label-ide.properties.alignment.description')
                }
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'CollapseText':
				thisWidget.jqElement.find('.anotherContent').text(value);
			case 'ButtonText':
				thisWidget.jqElement.find('.collapsible').text(value);
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-hello">' +
					'<button type="button" class="collapsible">' + this.getProperty('ButtonText') + '</button>' +
					'<div class="content">' +
						'<p class="anotherContent">' + this.getProperty('CollapseText') + '</p>' +
					'</div>' + 
				'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		//valueElem = this.jqElement.find('.hello-property');
		var button = this.jqElement.find('.collapsible');
		TW.log.debug(button);
		button.text(this.getProperty('ButtonText'));
		
		var content = this.jqElement.find('.anotherContent');
		TW.log.debug(content.text());
		content.text(this.getProperty('CollapseText'));
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		//valueElem.text(this.getProperty('hello Property'));
	};

};