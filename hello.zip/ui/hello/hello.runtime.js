TW.Runtime.Widgets.hello= function () {
	var valueElem, button, content;
	this.renderHtml = function() {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName). In
		// this example, we'll just return static HTML
		return '<div class="widget-content widget-hello">'
				+ '<button type="button" class="collapsible">' + this.getProperty('ButtonText') + '</button>'
				+ '<div class="content">' 
				+ '<p class="anotherContent">' + this.getProperty('CollapseText') + '</p>' 
				+ '</div>'
				+ '</div>';
	};

	this.afterRender = function () {
		TW.log.debug("Updated Code");
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		//valueElem = this.jqElement.find('.hello-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		//valueElem.text(this.getProperty('hello Property'));
		
		button = this.jqElement.find('.collapsible');
		button.text(this.getProperty('ButtonText'));
		
		content = this.jqElement.find('.anotherContent');
		content.text(this.getProperty('CollapseText'));
		content.css('display', 'none');
		button.click(function(e){
			TW.log.debug("Button Clicked");
			var displayValue = content.css("display");
			TW.log.debug("displayValue -> " + displayValue);
			if (displayValue === "block") {
				TW.log.debug("true");
				content.css('display', 'none');
			} else {
				TW.log.debug("false");
				content.css('display', 'block');
			}
		});
		
		
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'ButtonText') {
			button.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('ButtonText', updatePropertyInfo.SinglePropertyValue);
		}
		if (updatePropertyInfo.TargetProperty === 'CollapseText') {
			content.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('CollapseText', updatePropertyInfo.SinglePropertyValue);
		}
	};
};